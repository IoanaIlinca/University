#include "ui.h"
#include <stdio.h>


int main()
{
    Console();
	destroy(myList);
	return 0;
}
