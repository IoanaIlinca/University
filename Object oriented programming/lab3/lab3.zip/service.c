#include "service.h"


void InitializeService()
{
	InitializeRepo();
}

AllProfiles ServiceGetAll()
{
	return RepoGetAll();
}

int ServiceAddProfile(int profileIdNumber, char* placeOfBirth, char* psychologicalProfile, int yearsOfRecordedService)
{
	if (CheckExisting(profileIdNumber))
		return 0;
	Profile newProfile = CreateProfile(profileIdNumber, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
	RepoAddProfile(newProfile);
	return 1;

}

int ServiceUpdateProfile(int profileIdNumber, char* placeOfBirth, char* psychologicalProfile, int yearsOfRecordedService)
{
	if (!CheckExisting(profileIdNumber))
	{
		return 0;
	}
	Profile newProfile = CreateProfile(profileIdNumber, placeOfBirth, psychologicalProfile, yearsOfRecordedService);
	RepoUpdateProfile(newProfile);
	return 1;
}

int ServiceDeleteProfile(int profileIdNumber)
{
	if (!CheckExisting(profileIdNumber))
		return 0;
	RepoDeleteProfile(profileIdNumber);
	return 1;
}
