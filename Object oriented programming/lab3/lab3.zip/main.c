#include "ui.h"
#include <stdio.h>


int main()
{
    Console();
	return 0;
}
