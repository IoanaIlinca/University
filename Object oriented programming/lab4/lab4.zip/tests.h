#pragma once
#include <assert.h>
#include <stdlib.h>
#include "ui.h"

void testAll();
