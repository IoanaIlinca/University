#pragma once

#include <QtWidgets/QMainWindow>
//#include "ui_Exam3.h"

class Exam3 : public QMainWindow
{
    Q_OBJECT

public:
    Exam3(QWidget *parent = Q_NULLPTR);

//private:
   // Ui::Exam3Class ui;
};
