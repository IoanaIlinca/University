#pragma once
#include "service.h"
#include <assert.h>

class Tests {
public:
	void TestGetSelected();
};

void TestAll();