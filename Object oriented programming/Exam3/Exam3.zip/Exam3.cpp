#include "Exam3.h"

Exam3::Exam3(QWidget *parent)
    : QMainWindow(parent)
{
   // ui.setupUi(this);
}
