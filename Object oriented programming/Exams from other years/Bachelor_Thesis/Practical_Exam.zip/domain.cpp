#include "domain.h"

domain::domain()
{

}
