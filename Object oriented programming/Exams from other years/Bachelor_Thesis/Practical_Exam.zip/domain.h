#ifndef DOMAIN_H
#define DOMAIN_H


class domain
{
public:
    domain();
};

#endif // DOMAIN_H
