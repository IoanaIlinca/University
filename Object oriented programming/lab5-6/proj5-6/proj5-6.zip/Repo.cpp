#define _CRT_SECURE_NO_WARNINGS
#include "Repo.h"
#include <fstream>

using namespace std;

Repo::Repo()
{
	/*
	PieceOfEvidence piece("12sd23", "23X12X10", 0.2452, 13, "DSC13241.jpg");
	PieceOfEvidence piece2("16", "21", 0.2452, 16, "MyPic.jpg");
	PieceOfEvidence piece3("1223", "23X12X10", 0.2452, 13, "DSC13241.jpg");
	PieceOfEvidence piece4("30", "21", 0.2452, 16, "MyPic.jpg");
	PieceOfEvidence piece5("salata de boeuf", "177", 0.2452, 13, "DSC13241.jpg");
	PieceOfEvidence piece6("60", "23X12X10", 0.2452, 16, "MyPic.jpg");
	PieceOfEvidence piece7("88", "ana", 0.2452, 13, "DSC13241.jpg");
	PieceOfEvidence piece8("14", "ana", 0.2452, 16, "MyPic.jpg");
	PieceOfEvidence piece9("mere", "23X12X10", 0.2452, 13, "DSC13241.jpg");
	PieceOfEvidence piece10("133", "ana", 0.2452, 16, "MyPic.jpg");
	//Evidence.print();
	*/
}

void Repo::SavePath(string& path)
{
	
	//file = "fileLocation E:\\Faculta\\sem 2\\oop\\lab5-6\\proj5-6\\Evidence.txt";
	file = path;
	//cout << file;
}

vector<PieceOfEvidence> Repo::ReadFromFile()
{
	//cout << file << "***";
	ifstream fin(file, ios::in);
	//cout << fin.is_open() << ' ';
	string id = "0", measurement = "0", photograph = "0";
	double imageClarityLevel = 0;
	int quantity = 0;
	PieceOfEvidence piece(id, measurement, imageClarityLevel, quantity, photograph);
	vector<PieceOfEvidence> Evidence;
	string command;
	while (fin >> piece)
	{
		//cout << piece;
		
		/*
		

		int currentComma = 0, lastComma = 0;

		currentComma = command.find(",");

		id = command.substr(0, currentComma);
		command.erase(0, currentComma + 2);
		currentComma = command.find(",");

		measurement = command.substr(0, currentComma);
		command.erase(0, currentComma + 2);

		currentComma = command.find(",");

		imageClarityLevel = stod(command.substr(0, currentComma));

		command.erase(0, currentComma + 2);
		currentComma = command.find(",");

		quantity = stoi(command.substr(0, currentComma));

		command.erase(0, currentComma + 2);

		currentComma = command.find(",");

		photograph = command;
		//command.erase(0, currentComma + 2);
		*/
		
		Evidence.push_back(piece);
	}

	fin.close();
	return Evidence;
}


void Repo::AddPiece(PieceOfEvidence newPiece)
{
	//cout << file << "pwp";
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	Evidence.push_back(newPiece);
	ofstream fout;
	fout.open(file, ios::out);

	for (PieceOfEvidence piece : Evidence)
		fout << piece;

	fout.close();
}

void Repo::DeletePiece(PieceOfEvidence oldPiece)
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	int iterator = 0;
	for (auto piece : Evidence)
	{
		if (piece == oldPiece)
		{
			//cout << oldPiece;
			Evidence.erase(Evidence.begin() + iterator);
			break;
		}
		iterator++;
	}

	ofstream fout;
	fout.open(file, ios::out);

	for (PieceOfEvidence piece : Evidence)
		fout << piece;

	fout.close();
}

void Repo::UpdatePiece(PieceOfEvidence newPiece)
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	int iterator = 0;
	for (auto piece : Evidence)
	{
		if (piece == newPiece)
		{
			Evidence.emplace(Evidence.begin() + iterator, newPiece);
			Evidence.erase(Evidence.begin() + iterator + 1);
			
		}
		iterator++;
	}

	ofstream fout;
	fout.open(file, ios::out);

	for (PieceOfEvidence piece : Evidence)
		fout << piece;

	fout.close();
}

int Repo::GetSize()
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	return Evidence.size();
}

PieceOfEvidence Repo::GetElement(string id)
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	for (auto piece : Evidence)
	{
		if (piece.GetId() == id)
			return piece;
	}
	PieceOfEvidence piece2("-1", "", 0, 0, "");
	return piece2;
}

PieceOfEvidence Repo::Next()
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	position++;
	if (position >= Evidence.size())
		position = 0;
	return Evidence[position];
}

PieceOfEvidence Repo::Current()
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	if (position == -1)
		position = 0;
	return Evidence[position];
}

PieceOfEvidence Repo::Begin()
{
	vector<PieceOfEvidence> Evidence = ReadFromFile();
	return Evidence[0];
}


ostream& operator<<(ostream& output, const Repo& rep)
{
	ifstream fin(rep.file, ios::in);
	//cout << fin.is_open() << ' ';


	vector<PieceOfEvidence> Evidence;
	string command;
	while (getline(fin, command))
	{
		string id = "0", measurement = "0", photograph = "0";
		double imageClarityLevel = 0;
		int quantity = 0;

		int currentComma = 0, lastComma = 0;

		currentComma = command.find(",");

		id = command.substr(0, currentComma);
		command.erase(0, currentComma + 2);
		currentComma = command.find(",");

		measurement = command.substr(0, currentComma);
		command.erase(0, currentComma + 2);

		currentComma = command.find(",");

		imageClarityLevel = stod(command.substr(0, currentComma));

		command.erase(0, currentComma + 2);
		currentComma = command.find(",");

		quantity = stoi(command.substr(0, currentComma));

		command.erase(0, currentComma + 2);

		currentComma = command.find(",");

		photograph = command;
		//command.erase(0, currentComma + 2);

		PieceOfEvidence piece(id, measurement, imageClarityLevel, quantity, photograph);
		Evidence.push_back(piece);
	}

	fin.close();

	//for (int iterator = 0; iterator < m_size; iterator++)
	for (auto piece : Evidence)
		output << piece;
	return output;
}

Repo::~Repo()
{
	
}

RepoB::RepoB() 
{

}

RepoB::~RepoB()
{

}

void RepoB::SavePiece(PieceOfEvidence newPiece)
{
	MyList.push_back(newPiece);
}

int RepoB::GetSizeMyList()
{
	return MyList.size();
}


PieceOfEvidence RepoB::GetElement(string id)
{
	for (auto piece : MyList)
	{
		if (piece.GetId() == id)
			return piece;
	}
	PieceOfEvidence piece2("-1", "", 0, 0, "");
	return piece2;
}

ostream& operator<<(ostream& output, const RepoB& rep)
{

	//for (int iterator = 0; iterator < m_size; iterator++)
	for (auto piece : rep.MyList)
		output << piece;
	return output;
}