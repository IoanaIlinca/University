#pragma once
#include "PieceOfEvidence.h"
#include <vector>
using namespace std;

class Repo
{
protected:
	int position = -1;
	//char file[1001];
	string file = "";

public:
	/* Constructor, no parameters */
	Repo();

	/* Destructor, no parameters */
	~Repo();

	/*Saves the path of the file*/
	void SavePath(string& path);

	/*Reads the evidence from a text file*/
	vector<PieceOfEvidence> ReadFromFile();

	/* Getter - returns an element with a give id*/
	PieceOfEvidence GetElement(string id);

	/* Getter - returns the size of the repository */
	int GetSize();

	/*  Adds a piece in the array of pieces */
	void AddPiece(PieceOfEvidence newPiece);

	/*  Deletes a piece in the array of pieces*/
	void DeletePiece(PieceOfEvidence);

	/* Updates a piece in the array of pieces */
	void UpdatePiece(PieceOfEvidence newPiece);

	/* Overwrites the << operator */
	friend ostream& operator<<(ostream& output, const Repo& rep);

	/*Returns the next element*/
	PieceOfEvidence Next();

	/*Returns the current element*/
	PieceOfEvidence Current();

	/*Returns the first element*/
	PieceOfEvidence Begin();
};

class RepoB {
private:
	vector<PieceOfEvidence> MyList;

public:
	/*Constructor*/
	RepoB();

	/*Destructor*/
	~RepoB();

	/*Saves a piece to MyList*/
	void SavePiece(PieceOfEvidence newPiece);

	/*Gets an element from MyList given its id*/
	PieceOfEvidence GetElement(string id);

	/* Overwrites the << operator */
	friend ostream& operator<<(ostream& output, const RepoB& rep);

	/*Gets the size of MyList*/
	int GetSizeMyList();
};
