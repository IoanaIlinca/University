#include "tests.h"
#include "Ui.h"


int main()
{
	TestAll();

	Menu();


	_CrtDumpMemoryLeaks();

}


