#include "tests.h"
#include "Ui.h"
#include <windows.h>






int main()
{
	TestAll();

	Menu();


	_CrtDumpMemoryLeaks();

}


