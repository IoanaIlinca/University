/********************************************************************************
** Form generated from reading UI file 'Proj59_gui.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROJ59_GUI_H
#define UI_PROJ59_GUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Proj59_guiClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *modeAButton;
    QPushButton *modeBButton;
    QListWidget *evidenceListWidget;
    QStackedWidget *modesStackedWidget;
    QWidget *page_7;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_4;
    QListView *myListView;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *nextButton;
    QPushButton *saveButton;
    QPushButton *listButton;
    QPushButton *undoButtonMyList;
    QPushButton *redoButtonMyList;
    QWidget *Page1;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QFormLayout *formLayout;
    QLabel *idLabel;
    QLineEdit *idLineEdit;
    QLabel *measurementLabel;
    QLineEdit *measurementLineEdit;
    QLabel *quantityLabel;
    QLineEdit *quantityLineEdit;
    QLabel *imageClarityLevelLabel;
    QLineEdit *imageClarityLevelLineEdit;
    QLabel *photographLabel;
    QLineEdit *photographLineEdit;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QPushButton *updateButton;
    QPushButton *undoButton;
    QPushButton *redoButton;
    QWidget *myWidget;
    QVBoxLayout *verticalLayout_3;
    QFormLayout *filterShit;
    QLabel *label;
    QLineEdit *filterMeasurementLineEdit;
    QLabel *label_2;
    QLineEdit *filterQuantityLineEdit;
    QPushButton *doneButton;
    QPushButton *filterButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Proj59_guiClass)
    {
        if (Proj59_guiClass->objectName().isEmpty())
            Proj59_guiClass->setObjectName(QString::fromUtf8("Proj59_guiClass"));
        Proj59_guiClass->resize(535, 855);
        centralWidget = new QWidget(Proj59_guiClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        modeAButton = new QPushButton(centralWidget);
        modeAButton->setObjectName(QString::fromUtf8("modeAButton"));

        horizontalLayout->addWidget(modeAButton);

        modeBButton = new QPushButton(centralWidget);
        modeBButton->setObjectName(QString::fromUtf8("modeBButton"));

        horizontalLayout->addWidget(modeBButton);


        verticalLayout->addLayout(horizontalLayout);

        evidenceListWidget = new QListWidget(centralWidget);
        evidenceListWidget->setObjectName(QString::fromUtf8("evidenceListWidget"));

        verticalLayout->addWidget(evidenceListWidget);

        modesStackedWidget = new QStackedWidget(centralWidget);
        modesStackedWidget->setObjectName(QString::fromUtf8("modesStackedWidget"));
        page_7 = new QWidget();
        page_7->setObjectName(QString::fromUtf8("page_7"));
        layoutWidget = new QWidget(page_7);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 497, 221));
        verticalLayout_4 = new QVBoxLayout(layoutWidget);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        myListView = new QListView(layoutWidget);
        myListView->setObjectName(QString::fromUtf8("myListView"));

        verticalLayout_4->addWidget(myListView);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        nextButton = new QPushButton(layoutWidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));

        horizontalLayout_3->addWidget(nextButton);

        saveButton = new QPushButton(layoutWidget);
        saveButton->setObjectName(QString::fromUtf8("saveButton"));

        horizontalLayout_3->addWidget(saveButton);

        listButton = new QPushButton(layoutWidget);
        listButton->setObjectName(QString::fromUtf8("listButton"));

        horizontalLayout_3->addWidget(listButton);

        undoButtonMyList = new QPushButton(layoutWidget);
        undoButtonMyList->setObjectName(QString::fromUtf8("undoButtonMyList"));

        horizontalLayout_3->addWidget(undoButtonMyList);

        redoButtonMyList = new QPushButton(layoutWidget);
        redoButtonMyList->setObjectName(QString::fromUtf8("redoButtonMyList"));

        horizontalLayout_3->addWidget(redoButtonMyList);


        verticalLayout_4->addLayout(horizontalLayout_3);

        modesStackedWidget->addWidget(page_7);
        Page1 = new QWidget();
        Page1->setObjectName(QString::fromUtf8("Page1"));
        layoutWidget1 = new QWidget(Page1);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(1, 1, 511, 251));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        idLabel = new QLabel(layoutWidget1);
        idLabel->setObjectName(QString::fromUtf8("idLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, idLabel);

        idLineEdit = new QLineEdit(layoutWidget1);
        idLineEdit->setObjectName(QString::fromUtf8("idLineEdit"));

        formLayout->setWidget(0, QFormLayout::FieldRole, idLineEdit);

        measurementLabel = new QLabel(layoutWidget1);
        measurementLabel->setObjectName(QString::fromUtf8("measurementLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, measurementLabel);

        measurementLineEdit = new QLineEdit(layoutWidget1);
        measurementLineEdit->setObjectName(QString::fromUtf8("measurementLineEdit"));

        formLayout->setWidget(1, QFormLayout::FieldRole, measurementLineEdit);

        quantityLabel = new QLabel(layoutWidget1);
        quantityLabel->setObjectName(QString::fromUtf8("quantityLabel"));

        formLayout->setWidget(2, QFormLayout::LabelRole, quantityLabel);

        quantityLineEdit = new QLineEdit(layoutWidget1);
        quantityLineEdit->setObjectName(QString::fromUtf8("quantityLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, quantityLineEdit);

        imageClarityLevelLabel = new QLabel(layoutWidget1);
        imageClarityLevelLabel->setObjectName(QString::fromUtf8("imageClarityLevelLabel"));

        formLayout->setWidget(3, QFormLayout::LabelRole, imageClarityLevelLabel);

        imageClarityLevelLineEdit = new QLineEdit(layoutWidget1);
        imageClarityLevelLineEdit->setObjectName(QString::fromUtf8("imageClarityLevelLineEdit"));

        formLayout->setWidget(3, QFormLayout::FieldRole, imageClarityLevelLineEdit);

        photographLabel = new QLabel(layoutWidget1);
        photographLabel->setObjectName(QString::fromUtf8("photographLabel"));

        formLayout->setWidget(4, QFormLayout::LabelRole, photographLabel);

        photographLineEdit = new QLineEdit(layoutWidget1);
        photographLineEdit->setObjectName(QString::fromUtf8("photographLineEdit"));

        formLayout->setWidget(4, QFormLayout::FieldRole, photographLineEdit);


        verticalLayout_2->addLayout(formLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        addButton = new QPushButton(layoutWidget1);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        horizontalLayout_2->addWidget(addButton);

        deleteButton = new QPushButton(layoutWidget1);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));

        horizontalLayout_2->addWidget(deleteButton);

        updateButton = new QPushButton(layoutWidget1);
        updateButton->setObjectName(QString::fromUtf8("updateButton"));

        horizontalLayout_2->addWidget(updateButton);

        undoButton = new QPushButton(layoutWidget1);
        undoButton->setObjectName(QString::fromUtf8("undoButton"));

        horizontalLayout_2->addWidget(undoButton);

        redoButton = new QPushButton(layoutWidget1);
        redoButton->setObjectName(QString::fromUtf8("redoButton"));

        horizontalLayout_2->addWidget(redoButton);


        verticalLayout_2->addLayout(horizontalLayout_2);

        modesStackedWidget->addWidget(Page1);

        verticalLayout->addWidget(modesStackedWidget);

        myWidget = new QWidget(centralWidget);
        myWidget->setObjectName(QString::fromUtf8("myWidget"));
        verticalLayout_3 = new QVBoxLayout(myWidget);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        filterShit = new QFormLayout();
        filterShit->setSpacing(6);
        filterShit->setObjectName(QString::fromUtf8("filterShit"));
        label = new QLabel(myWidget);
        label->setObjectName(QString::fromUtf8("label"));

        filterShit->setWidget(0, QFormLayout::LabelRole, label);

        filterMeasurementLineEdit = new QLineEdit(myWidget);
        filterMeasurementLineEdit->setObjectName(QString::fromUtf8("filterMeasurementLineEdit"));

        filterShit->setWidget(0, QFormLayout::FieldRole, filterMeasurementLineEdit);

        label_2 = new QLabel(myWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        filterShit->setWidget(1, QFormLayout::LabelRole, label_2);

        filterQuantityLineEdit = new QLineEdit(myWidget);
        filterQuantityLineEdit->setObjectName(QString::fromUtf8("filterQuantityLineEdit"));

        filterShit->setWidget(1, QFormLayout::FieldRole, filterQuantityLineEdit);

        doneButton = new QPushButton(myWidget);
        doneButton->setObjectName(QString::fromUtf8("doneButton"));

        filterShit->setWidget(3, QFormLayout::FieldRole, doneButton);

        filterButton = new QPushButton(myWidget);
        filterButton->setObjectName(QString::fromUtf8("filterButton"));

        filterShit->setWidget(3, QFormLayout::LabelRole, filterButton);


        verticalLayout_3->addLayout(filterShit);


        verticalLayout->addWidget(myWidget);

        Proj59_guiClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Proj59_guiClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 535, 26));
        Proj59_guiClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Proj59_guiClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        Proj59_guiClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Proj59_guiClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        Proj59_guiClass->setStatusBar(statusBar);

        retranslateUi(Proj59_guiClass);

        modesStackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Proj59_guiClass);
    } // setupUi

    void retranslateUi(QMainWindow *Proj59_guiClass)
    {
        Proj59_guiClass->setWindowTitle(QCoreApplication::translate("Proj59_guiClass", "Proj59_gui", nullptr));
        modeAButton->setText(QCoreApplication::translate("Proj59_guiClass", "Mode A", nullptr));
        modeBButton->setText(QCoreApplication::translate("Proj59_guiClass", "Mode B", nullptr));
        nextButton->setText(QCoreApplication::translate("Proj59_guiClass", "Next", nullptr));
        saveButton->setText(QCoreApplication::translate("Proj59_guiClass", "Save", nullptr));
        listButton->setText(QCoreApplication::translate("Proj59_guiClass", "List", nullptr));
        undoButtonMyList->setText(QCoreApplication::translate("Proj59_guiClass", "Undo", nullptr));
        redoButtonMyList->setText(QCoreApplication::translate("Proj59_guiClass", "Redo", nullptr));
        idLabel->setText(QCoreApplication::translate("Proj59_guiClass", "Id:", nullptr));
        measurementLabel->setText(QCoreApplication::translate("Proj59_guiClass", "Measurement:", nullptr));
        quantityLabel->setText(QCoreApplication::translate("Proj59_guiClass", "Quantity: ", nullptr));
        imageClarityLevelLabel->setText(QCoreApplication::translate("Proj59_guiClass", "Image clarity level:", nullptr));
        photographLabel->setText(QCoreApplication::translate("Proj59_guiClass", "Photograph:", nullptr));
        addButton->setText(QCoreApplication::translate("Proj59_guiClass", "Add", nullptr));
        deleteButton->setText(QCoreApplication::translate("Proj59_guiClass", "Delete", nullptr));
        updateButton->setText(QCoreApplication::translate("Proj59_guiClass", "Update", nullptr));
        undoButton->setText(QCoreApplication::translate("Proj59_guiClass", "Undo", nullptr));
        redoButton->setText(QCoreApplication::translate("Proj59_guiClass", "Redo", nullptr));
        label->setText(QCoreApplication::translate("Proj59_guiClass", "Measurement", nullptr));
        label_2->setText(QCoreApplication::translate("Proj59_guiClass", "Quantity", nullptr));
        doneButton->setText(QCoreApplication::translate("Proj59_guiClass", "Done", nullptr));
        filterButton->setText(QCoreApplication::translate("Proj59_guiClass", "Filter", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Proj59_guiClass: public Ui_Proj59_guiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROJ59_GUI_H
