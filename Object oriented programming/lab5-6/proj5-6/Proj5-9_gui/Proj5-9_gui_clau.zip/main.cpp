#include "Proj59_gui.h"
#include "Service.h"
#include "tests.h"
#include <QtWidgets/QApplication>


int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	
	//TestAll();
	ServiceB<RepoBMemory> serv;
	string path = "Evidence.txt";
	string mylistPath = "MyList.txt";
	//serv.ServicePath(path);
	//serv.ServicePathB(mylistPath);

	//GUI gui{serv};
	//gui.resize(500, 500);
	//gui.show();
	//w.show();
	Proj59_gui gui{serv};
	gui.show();
	
	
	return a.exec();
}
