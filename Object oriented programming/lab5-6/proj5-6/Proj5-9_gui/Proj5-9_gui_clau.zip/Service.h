#pragma once
#include "Repo.h"
#include "Validator.h"
#include "RepoMemory.h"
#include "Actions.h"
#include <stack>
#include <fstream>
using namespace std;

template <typename T>
class Service
{
protected:

	T repository;
	PieceValidator validator;
	stack<unique_ptr<Action>> actionsUndo;
	stack<unique_ptr<Action>> actionsRedo;

public:
	/* Constructor, no parameters */
	//Service();
	/* Destructor, no parameters */
	//~Service();

	//string Undo();
	//string Redo();

	/*Makes sure the path exists, and passes to repo*/
	//void ServicePath(string& path);

	/*  Creates a piece and adds it to the repository
		returns true if successful, false otherwise */
	virtual string ServiceAdd(string id, string measurement, double imageClarityLevel, int quantity, string photograph);

	/* Creates a new piece with the new values and replaces the old one in te repository
		returns true if successful, false otherwise */
	virtual string ServiceUpdate(string id, string newMeasurement, double newImageClarityLevel, int newQuantity, string newPhotograph);

	/* Deletes a piece with a given id form the repository
		returns true if successful, false otherwise */
	virtual string ServiceDelete(string id);

	/* Getter
		returns a copy of the repository */
	//Repo GetRepository();

	virtual vector<PieceOfEvidence> GetEvidence();

	/* Getter
		it gets an id and returns a PieceOfEvidence (with id -1 if it hasn't been found ) */
	virtual PieceOfEvidence ServiceElement(string id);

	/* Overwrites the << operator */
	//friend ostream& operator<<(ostream& output, const Service& serv);

	/* Returns the size of the repository */
	virtual int GetSize();
};

class ServiceFile : public Service<Repo> {
//protected:
	//Repo repository; 

public:
	/*Makes sure the path exists, and passes to repo*/
	void ServicePath(string& path);
};


template <typename T>
class ServiceB : public Service<RepoMemory> {
protected:
	//RepoBMemory repositoryMyList;
	T repositoryMyList;

public:
	/*Saves a piece to MyList*/
	bool SaveIdToMyList(string id);

	/* Overwrites the << operator */
	//friend ostream& operator<<(ostream& output, const ServiceB& serv);

	/*Gets the size of MyList*/
	int GetSizeMyList();

	/*Returns the next element*/
	PieceOfEvidence Next();

	/*Returns the next element with a certain measurement*/
	PieceOfEvidence Next(string measurement);

	/*Returns the current element*/
	PieceOfEvidence Current();

	/*Returns the first element*/
	PieceOfEvidence Begin();

	/*Gets the elements with a certain measurement and a greater or equal quantity with the parameter*/
	vector<PieceOfEvidence> GetElements(string measurement, int quantity);

	vector<PieceOfEvidence> GetMyList();
};

class ServiceBFile : public ServiceB<RepoB> /*Protected?*/{
protected:
	Repo repository;
	//RepoB repositoryMyList;

public:
	//ServiceBFile();
	//~ServiceBFile();

	void ServicePath(string& path);

	/*Passed the path to repoB*/
	void ServicePathB(string& path);
};

template <typename T>
int ServiceB<T>::GetSizeMyList()
{
	return repositoryMyList.GetSizeMyList();
}

template <typename T>
PieceOfEvidence ServiceB<T>::Next()
{
	return repository.Next();
}

template <typename T>
PieceOfEvidence ServiceB<T>::Next(string measurement)
{
	for (int i = 0; i <= repository.GetSize(); i++)
	{
		if (repository.Next().GetMeasurement() == measurement)
			return repository.Current();
	}
	PieceOfEvidence piece("-1", "", 0, 0, "");
	return piece;
}

template <typename T>
PieceOfEvidence ServiceB<T>::Current()
{
	return repository.Current();
}

template <typename T>
PieceOfEvidence ServiceB<T>::Begin()
{
	return repository.Begin();
}

template <typename T>
vector<PieceOfEvidence> ServiceB<T>::GetElements(string measurement, int quantity)
{
	vector<PieceOfEvidence> result;
	for (int i = 0; i < repository.GetSize(); i++)
	{
		PieceOfEvidence piece = repository.Next();
		if (piece.GetMeasurement() == measurement && piece.GetQuantity() >= quantity)
		{
			result.push_back(piece);
		}

	}
	return result;
}

template <typename T>
vector<PieceOfEvidence> ServiceB<T>::GetMyList()
{
	vector<PieceOfEvidence> result = repositoryMyList.GetMyList();
	return result;
}


template <typename T>
bool ServiceB<T> ::SaveIdToMyList(string id)
{
	PieceOfEvidence piece = ServiceElement(id);
	PieceOfEvidence piece2("-1", "", 0, 0, "");
	if (repository.GetElement(id) == piece2) // id does not exist, the item can't be added to myList
	{
		return false;
	}


	if (repositoryMyList.GetElement(id) == piece2) // if the element is not already in the list, we add it
		repositoryMyList.SavePiece(piece);
	return true;
}

template <typename T>
string Service<T>::ServiceAdd(string id, string measurement, double imageClarityLevel, int quantity, string photograph)
{
	PieceOfEvidence piece(id, measurement, imageClarityLevel, quantity, photograph);

	try {
		validator.validate(piece);
	}
	catch (ValidationException exception) {
		return exception.getMessage();
	}
	try {
		repository.AddPiece(piece);
	}
	catch (ValidationException exception) {
		return exception.getMessage();
	}
	//unique_ptr<Repo> ptr = make_unique<Repo>(repository);
	//repository.AddPiece(piece);
	//unique_ptr<RepoMemory> ptr = make_unique<RepoMemory>(repository);
	//unique_ptr<ActionAdd> thisAction = make_unique<ActionAdd>(move(ptr), piece);
	//actionsUndo.emplace(move(thisAction));
	return "";
}

template <typename T>
string Service<T>::ServiceUpdate(string id, string newMeasurement, double newImageClarityLevel, int newQuantity, string newPhotograph)
{
	PieceOfEvidence piece(id, newMeasurement, newImageClarityLevel, newQuantity, newPhotograph);
	PieceOfEvidence oldPiece;
	oldPiece = repository.GetElement(id);
	PieceOfEvidence piece2("-1", "", 0, 0, "");
	try {
		validator.validate(piece);
	}
	catch (ValidationException exception) {
		return exception.getMessage();
	}
	try {
		repository.UpdatePiece(piece);
	}
	catch (ValidationException exception) {
		return exception.getMessage();
	}

	//ActionUpdate thisAction(make_unique<Repo>(repository), oldPiece, piece);
	//actionsUndo.emplace(thisAction);
	//unique_ptr<RepoMemory> ptr = make_unique<RepoMemory>(repository);
	//unique_ptr<ActionUpdate> thisAction = make_unique<ActionUpdate>(move(ptr), oldPiece, piece);
	//actionsUndo.emplace(move(thisAction));
	return "";

}

template <typename T>
string Service<T>::ServiceDelete(string id)
{
	PieceOfEvidence piece = repository.GetElement(id);
	//unique_ptr<RepoMemory> ptr = make_unique<RepoMemory>(repository);
	//unique_ptr<ActionRemove> thisAction = make_unique<ActionRemove>(move(ptr), piece);
	//actionsUndo.emplace(move(thisAction));
	PieceOfEvidence piece2("-1", "", 0, 0, "");
	if (piece == piece2)
		return "Id does not exist";
	else
	{
		repository.DeletePiece(piece);
		return "";
	}

	//ActionRemove thisAction(make_unique<Repo>(repository), piece);
	//actionsUndo.emplace(thisAction);

}
/*
Repo Service::GetRepository()
{
	return repository;
}*/

template <typename T>
vector<PieceOfEvidence> Service<T>::GetEvidence()
{
	//return repository.ReadFromFile();
	return repository.GetEvidence();
}

template <typename T>
PieceOfEvidence Service<T>::ServiceElement(string id)
{
	return repository.GetElement(id);
}

template <typename T>
int Service<T>::GetSize()
{
	return repository.GetSize();
}


/*
ostream& operator<<(ostream& output, const ServiceB& serv)
{

	//for (int iterator = 0; iterator < m_size; iterator++)
	output << serv.repositoryMyList;
	return output;
}
*/

/*
void ServiceBFile::ServicePath(string& path)
{
	fstream file;
	file.open(path, ios::in);
	//cout << file.is_open() << ' ';
	if (!file.is_open())
		file.open(path, ios::out | ios::app); // makes sure the file exists, if it doesn't, it creates a new one

	file.close();

	repository.SavePath(path);
}

void ServiceBFile::ServicePathB(string& path)
{
	fstream file;
	file.open(path, ios::in);
	//cout << file.is_open() << ' ';
	if (!file.is_open())
		file.open(path, ios::out | ios::app); // makes sure the file exists, if it doesn't, it creates a new one

	file.close();

	repositoryMyList.SavePathMyList(path);
}*/