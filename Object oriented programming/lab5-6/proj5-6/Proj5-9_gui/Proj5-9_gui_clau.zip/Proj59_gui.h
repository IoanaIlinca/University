#pragma once
#include <QtWidgets/QMainWindow>
#include "ui_Proj59_gui.h"
#include "Service.h"

template <class T>
class Proj59_gui : public QMainWindow
{
	Q_OBJECT

public:
	Proj59_gui(ServiceB<RepoBMemory>& s, int i, QWidget *parent = Q_NULLPTR)
	Proj59_gui(ServiceBFile& s, QWidget *parent = Q_NULLPTR);

private:
	//template <typename T>
	ServiceB<RepoBMemory>& serv;
	ServiceBFile& serv;
	Ui::Proj59_guiClass ui;

	void populateList();
	void populateMylist();
	void connectSignalsAndSlots();
	int getSelectedIndex() const;
	int getSelectedIndexMylist() const;
	void AddPiece();
	void UpdatePiece();
	void DeletePiece();
	void ModeA();
	void ModeB();
	void Next();
	void Save();
	void Filter();
	void Done();
	void List();

};

