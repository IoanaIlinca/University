#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Proj59_gui.h"

class Proj59_gui : public QMainWindow
{
	Q_OBJECT

public:
	Proj59_gui(QWidget *parent = Q_NULLPTR);

private:
	Ui::Proj59_guiClass ui;
};
