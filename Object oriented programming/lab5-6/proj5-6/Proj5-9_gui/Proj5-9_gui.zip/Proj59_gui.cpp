#include "Proj59_gui.h"

Proj59_gui::Proj59_gui(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
