#include "Proj59_gui.h"
#include "Service.h"
#include "tests.h"
#include "GUI.h"
#include <QtWidgets/QApplication>


int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	
	//TestAll();
	Service serv;
	string path = "Evidence.txt";
	serv.ServicePath(path);

	GUI gui{serv};
	gui.resize(500, 500);
	gui.show();

	
	return a.exec();
}
